import App from './src/App'
import { registerRootComponent } from 'expo'

registerRootComponent(App)